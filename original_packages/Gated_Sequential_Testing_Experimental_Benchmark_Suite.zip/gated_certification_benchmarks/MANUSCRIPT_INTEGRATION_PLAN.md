# Manuscript Integration Plan

## Recommended new section

Add **Experimental Evaluation** after the analytical examples and before the physical/world-model implications.

Suggested subsections:

1. Experimental goals and reproducibility
2. Binary theorem validation
3. Record-envelope and deeper-ladder validation
4. Finite-confidence behavior
5. Multihypothesis exploratory extension
6. Robustness beyond the assumptions
7. External sequential-sensing replay

## Main claims to connect to figures

### Lower-bound tightness / first-order optimality
Use `binary_sample_complexity.png` and `binary_first_order.png`. State that simulations numerically support convergence to the proved first-order constant; do not say the finite-delta lower bound is exactly achieved.

### Price of Certification
Use `poc_surface.png` plus `empirical_poc_regimes.png`. Distinguish the theoretical asymptotic ratio from the empirical finite-confidence stopping-time ratio.

### Record envelope
Use `lp_verification.png`. The strongest reviewer-facing result is not a qualitative plot but the numerical equality between the direct LP optimum and the closed-form record-envelope value over random non-monotone instances.

### Multi-level behavior
Use `ladder_depth_empirical.png` and place detailed stage counts in supplement.

### Anytime control
Turn `false_unlock_calibration.csv` into a calibration plot with target alpha on x-axis and empirical false-unlock probability + Wilson intervals on y-axis; include the y=x line.

### Finite confidence
Use `finite_confidence.csv` to compare `L_delta`, `U_thr`, `U_bd`, and empirical mean stopping time. Preserve the paper's distinction between boundary-design slack and overshoot-bound slack.

### Multihypothesis
Use one compact N=3/5/10 plot in supplement/main discussion. Phrase as "exploratory evidence for the extension". The switching construction is particularly useful because it shows exactly where the scalar hardest-alternative reduction stops applying.

### Robustness
Correlation and misspecification plots belong in a subsection explicitly titled "Robustness beyond the formal assumptions." If performance degrades, report it: this defines the theorem's practical boundary.

### External replay
The UCI study should be one compact table. Do not claim it validates physical certification semantics. It demonstrates that a weak/strong sensing hierarchy can be calibrated on real sensor data and used in sequential replay.

## Suggested wording for the experimental section opening

> The theoretical results characterize binary certification ladders under known action-conditioned laws. Our experiments serve three distinct purposes. First, controlled Bernoulli simulations test the finite-confidence and asymptotic predictions in a setting where the KL rates and information lower bounds are known exactly. Second, multilevel, multihypothesis, dependent, Gaussian, and misspecified simulations probe the boundary of the assumptions rather than extending theorems by experiment. Third, an external sensor replay on UCI HAR illustrates how a weak-to-strong sensing hierarchy can be instantiated after fitting action-conditioned observation models from training data. We report these groups separately to avoid conflating theorem validation with robustness or application evidence.

## Tables recommended

### Main Table A — binary benchmark
Columns: delta, method, mean tau (95% CI), median, q95, H0 error, H1 error, false unlock, mean weak samples, mean strong samples, empirical PoC, lower-bound ratio.

### Main Table B — calibration
Columns: alpha target, empirical false unlock (95% CI), delta, H0 terminal error, H1 terminal error.

### External Table — UCI replay
Columns: policy, class/scenario, mean tau, error, weak samples, strong samples, unlock rate.

## What not to add to the paper

- random image/classification datasets;
- CNN/LSTM/Transformer comparisons unrelated to the theoretical question;
- a claim that Gaussian/correlated simulations prove a theorem outside its assumptions;
- a claim that UCI/PRISM passive replay proves physical safety;
- smoke-test results from this package.
